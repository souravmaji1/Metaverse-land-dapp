const Plane = () => {
    return (
        <mesh position={[0, 0, 0]}>
            <planeBufferGeometry attach="geometry" args={[170, 170]} />
            <meshStandardMaterial color={"black"} />
        </mesh>
    );
}

export default Plane;